# نقدي (Nqdi) — Flutter Migration

A clean, production-ready Flutter port of the Nqdi web app. Moroccan-Darija UI,
Material 3, Riverpod state management, and a fully procedural budget tree.

## Architecture (MVVM + clean separation)

```
lib/
├── main.dart                      # Entry: ProviderScope, RTL, theme, routing
├── core/
│   └── app_theme.dart             # Design tokens (colors, radii) + M3 theme
├── models/
│   └── models.dart                # Pure domain models — no Flutter imports
├── providers/
│   └── app_state.dart             # ViewModel: NqdiController + NqdiState
│                                  #   ↳ savings engine, validation, tree logic,
│                                  #     white-day & resistance gamification
├── painters/
│   └── tree_painter.dart          # CustomPainter for the 4-stage budget tree
├── screens/
│   ├── onboarding_screen.dart     # 4-step setup wizard
│   └── dashboard_screen.dart      # Shell + Material 3 NavigationBar
└── widgets/
    ├── common.dart                # Reusable buttons, fields, toast, step bar
    └── tabs/
        ├── today_tab.dart         # Tree, chips, allowance, savings, logging, pie
        ├── month_tab.dart         # Ratios, stats, comparison bars, debts, history
        ├── prosperity_tab.dart    # Tips ticker (coming soon)
        └── profile_tab.dart       # Edit info, resistance stats, full reset
```

The **UI never mutates state directly.** Every screen reads computed getters
from `NqdiState` and calls intent methods on `NqdiController`, which return an
`ActionResult` the UI turns into a toast. This keeps logic testable in isolation.

## Feature parity checklist

- ✅ **Dynamic Bonsai/budget tree** — `CustomPainter`, 4 health stages
  (healthy ≥75% · stable ≥40% · wilting ≥15% · dead), animated foliage tween.
- ✅ **نهار بيض (White Day)** challenge — blocks spending; completing a
  zero-spend day increments the streak.
- ✅ **لیوم قاومت (Resistance tracker)** — victory bonus = avg of danger-category
  estimates, accumulated into `bonusTotal`.
- ✅ **Name validation** — letters only, no ASCII or Arabic-Indic digits.
- ✅ **Phone validation** — Moroccan `06`/`07` + 10 digits.
- ✅ **15% automated savings engine** — `savingsGoal = (salary − fixed) × 0.15`.
- ✅ Debt ledger, per-day history, pie + estimate-vs-actual comparison charts.

## Getting Started

1. **Create a fresh Flutter project** (Flutter 3.24+ / Dart 3.5+):
   ```bash
   flutter create nqdi
   cd nqdi
   ```

2. **Copy files in:** replace the generated `lib/` and `pubspec.yaml` with the
   ones from this package (preserve the folder structure above).

3. **Add the Cairo font.** Download the weights from
   [Google Fonts → Cairo](https://fonts.google.com/specimen/Cairo) and drop them
   in `assets/fonts/` (filenames must match `pubspec.yaml`). To skip fonts for a
   quick test, comment out the `fonts:` block in `pubspec.yaml` — the app falls
   back to the system font.

4. **Install dependencies & run:**
   ```bash
   flutter pub get
   flutter run
   ```

## Notes

- **State persistence:** the web build kept everything in memory per session;
  this port does the same. To persist across launches, wrap `NqdiController`
  with `shared_preferences` or `hive` — serialize `NqdiState` in `copyWith`
  callbacks. The architecture makes this a localized change.
- **Lottie:** listed as a dependency for an optional richer victory animation.
  The tree itself is fully `CustomPainter` (no asset needed).
- **Day advancement:** `currentDay` is exposed in state; add a "next day"
  control or a date-based scheduler to advance it as the original prototype did.
