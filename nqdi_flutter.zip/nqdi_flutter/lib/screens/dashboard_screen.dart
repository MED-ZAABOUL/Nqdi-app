// lib/screens/dashboard_screen.dart
//
// Dashboard shell: a shared header + Material 3 NavigationBar driving four
// tab views (Today / Month / Prosperity / Profile). Each tab lives in its own
// widget file under lib/widgets/tabs/ to keep this file small.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../core/app_theme.dart';
import '../widgets/tabs/today_tab.dart';
import '../widgets/tabs/month_tab.dart';
import '../widgets/tabs/prosperity_tab.dart';
import '../widgets/tabs/profile_tab.dart';
import '../providers/app_state.dart';

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});
  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  int _tab = 0;

  static const _arMonths = [
    'يناير','فبراير','مارس','أبريل','ماي','يونيو',
    'يوليوز','غشت','شتنبر','أكتوبر','نونبر','دجنبر'
  ];

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final monthLabel = '${_arMonths[now.month - 1]} ${now.year}';
    final hasDebts = ref.watch(nqdiProvider.select((s) => s.hasDebts));

    final tabs = const [TodayTab(), MonthTab(), ProsperityTab(), ProfileTab()];

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(children: [
          // Shared header
          Container(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 12),
            decoration: const BoxDecoration(
              color: AppColors.white,
              border: Border(bottom: BorderSide(color: AppColors.border)),
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Row(children: [
                Container(
                  width: 30, height: 30,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [AppColors.green, AppColors.greenD]),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Center(child: Text('🌳', style: TextStyle(fontSize: 16))),
                ),
                const SizedBox(width: 8),
                const Text('نقدي', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              ]),
              Text(monthLabel, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.text3)),
            ]),
          ),
          Expanded(
            child: IndexedStack(index: _tab, children: tabs),
          ),
        ]),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        backgroundColor: AppColors.white,
        indicatorColor: AppColors.greenL,
        destinations: [
          const NavigationDestination(icon: Text('☀️', style: TextStyle(fontSize: 20)), label: 'اليوم'),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: hasDebts,
              child: const Text('📅', style: TextStyle(fontSize: 20)),
            ),
            label: 'الشهر',
          ),
          const NavigationDestination(icon: Text('🚀', style: TextStyle(fontSize: 20)), label: 'الازدهار'),
          const NavigationDestination(icon: Text('👤', style: TextStyle(fontSize: 20)), label: 'الملف'),
        ],
      ),
    );
  }
}

/// Tiny shared helper for formatting used by tab widgets.
String dh(num n) => '${NumberFormat.decimalPattern('ar_MA').format(n.round())} درهم';
