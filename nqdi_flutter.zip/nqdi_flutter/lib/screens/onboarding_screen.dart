// lib/screens/onboarding_screen.dart
//
// The 4-step setup wizard: profile → budget → categories → estimates.
// Each step validates through the controller before advancing. On completion
// it calls finalizeOnboarding() and pushes the dashboard.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/app_theme.dart';
import '../models/models.dart';
import '../providers/app_state.dart';
import '../widgets/common.dart';
import 'dashboard_screen.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});
  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final _page = PageController();
  int _step = 1;

  // Step 1
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _phone = TextEditingController();
  bool _phoneErr = false;

  // Step 2
  final _salary = TextEditingController();

  // Step 4 — one controller per active category, created lazily.
  final Map<String, TextEditingController> _est = {};

  @override
  void dispose() {
    for (final c in [_first, _last, _phone, _salary, ..._est.values]) {
      c.dispose();
    }
    _page.dispose();
    super.dispose();
  }

  void _go(int step) {
    setState(() => _step = step);
    _page.animateToPage(step - 1,
        duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
  }

  void _submitStep1() {
    final ctrl = ref.read(nqdiProvider.notifier);
    final res = ctrl.submitProfile(_first.text, _last.text, _phone.text);
    if (res.status != ActionStatus.success) {
      setState(() => _phoneErr = !NqdiController.isValidPhone(_phone.text));
      showToast(context, res);
      return;
    }
    setState(() => _phoneErr = false);
    _go(2);
  }

  void _submitStep2() {
    final value = double.tryParse(_salary.text) ?? 0;
    final res = ref.read(nqdiProvider.notifier).setSalary(value);
    if (res.status != ActionStatus.success) return showToast(context, res);
    _go(3);
  }

  void _submitStep3() {
    final res = ref.read(nqdiProvider.notifier).confirmCategories();
    if (res.status != ActionStatus.success) return showToast(context, res);
    // Prepare estimate controllers for selected categories.
    final active = ref.read(nqdiProvider).activeCategories;
    for (final c in active) {
      _est.putIfAbsent(c.id, () => TextEditingController());
    }
    _go(4);
  }

  void _finish() {
    final ctrl = ref.read(nqdiProvider.notifier);
    for (final entry in _est.entries) {
      ctrl.setEstimate(entry.key, double.tryParse(entry.value.text) ?? 0);
    }
    ctrl.finalizeOnboarding();
    final name = ref.read(nqdiProvider).firstName;
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const DashboardScreen()));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // toast on the next screen
    });
    debugPrint('Onboarding complete for $name');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: PageView(
          controller: _page,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            _StepProfile(
              first: _first, last: _last, phone: _phone,
              phoneErr: _phoneErr, onNext: _submitStep1,
              onPhoneChanged: () { if (_phoneErr) setState(() => _phoneErr = false); },
            ),
            _StepBudget(salary: _salary, onBack: () => _go(1), onNext: _submitStep2),
            _StepCategories(onBack: () => _go(2), onNext: _submitStep3),
            _StepEstimates(estControllers: _est, onBack: () => _go(3), onFinish: _finish),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────── STEP 1: PROFILE ───────────────────────────

class _StepProfile extends StatelessWidget {
  final TextEditingController first, last, phone;
  final bool phoneErr;
  final VoidCallback onNext, onPhoneChanged;
  const _StepProfile({
    required this.first, required this.last, required this.phone,
    required this.phoneErr, required this.onNext, required this.onPhoneChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Hero
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(28, 44, 28, 40),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight, end: Alignment.bottomLeft,
              colors: [AppColors.green, AppColors.greenD, Color(0xFF047857)],
            ),
          ),
          child: Column(children: [
            Container(
              width: 76, height: 76,
              decoration: BoxDecoration(
                color: Colors.white24, borderRadius: BorderRadius.circular(24),
                border: Border.all(color: Colors.white30, width: 2),
              ),
              child: const Center(child: Text('🌳', style: TextStyle(fontSize: 38))),
            ),
            const SizedBox(height: 18),
            const Text('نقدي',
                style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: Colors.white)),
            const SizedBox(height: 6),
            const Text('دير حساب على فلوسك بالدارجة\nسهل، ذكي، مغربي 100%',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: Colors.white70, height: 1.6)),
          ]),
        ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(22, 22, 22, 22),
            child: Column(children: [
              const StepBar(step: 1),
              const SizedBox(height: 22),
              Row(children: [
                Expanded(child: NqdiField(controller: first, label: 'الاسم الشخصي', hint: 'مثلاً: يوسف')),
                const SizedBox(width: 10),
                Expanded(child: NqdiField(controller: last, label: 'الاسم العائلي', hint: 'مثلاً: العلوي')),
              ]),
              const SizedBox(height: 18),
              NqdiField(
                controller: phone, label: 'رقم الهاتف بالمغرب',
                hint: '06 XX XX XX XX', keyboardType: TextInputType.phone,
                maxLength: 10, error: phoneErr, onChanged: (_) => onPhoneChanged(),
              ),
              if (phoneErr)
                const Padding(
                  padding: EdgeInsets.only(top: 6),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: Text('الرقم خاصو يبدأ بـ 06 أو 07 و10 أرقام',
                        style: TextStyle(fontSize: 11, color: AppColors.red, fontWeight: FontWeight.w600)),
                  ),
                ),
            ]),
          ),
        ),
        _NavBar(children: [Expanded(child: PrimaryButton(label: 'التالي ←', onPressed: onNext))]),
      ],
    );
  }
}

// ─────────────────────────── STEP 2: BUDGET ───────────────────────────

class _StepBudget extends StatelessWidget {
  final TextEditingController salary;
  final VoidCallback onBack, onNext;
  const _StepBudget({required this.salary, required this.onBack, required this.onNext});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      _TopBar(title: 'الميزانية الشهرية', subtitle: 'شحال جمعتي هاد الشهر؟', onBack: onBack),
      Expanded(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(22, 20, 22, 22),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const StepBar(step: 2),
            const SizedBox(height: 24),
            Row(children: [
              Container(width: 5, height: 5,
                  decoration: const BoxDecoration(color: AppColors.green, shape: BoxShape.circle)),
              const SizedBox(width: 6),
              const Expanded(
                child: Text('شحال الصالير أو الميزانية ديالك هاد الشهر؟',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.text2)),
              ),
            ]),
            const SizedBox(height: 10),
            Stack(children: [
              TextField(
                controller: salary,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w900),
                decoration: InputDecoration(
                  hintText: '5000',
                  contentPadding: const EdgeInsets.fromLTRB(80, 22, 20, 22),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(AppRadius.r),
                    borderSide: const BorderSide(color: AppColors.border2, width: 2),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(AppRadius.r),
                    borderSide: const BorderSide(color: AppColors.green, width: 2),
                  ),
                ),
              ),
              Positioned(
                left: 0, top: 0, bottom: 0,
                child: Container(
                  width: 68,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(colors: [AppColors.green, AppColors.greenD]),
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(AppRadius.r), bottomLeft: Radius.circular(AppRadius.r)),
                  ),
                  child: const Center(
                      child: Text('درهم',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13))),
                ),
              ),
            ]),
            const SizedBox(height: 18),
            _tip('💼', 'الراتب الأساسي:', 'دخل المبلغ كامل قبل ما تحسب الخصومات'),
            _tip('💰', 'نصيحة:', 'زيد الزيادات والدخل الإضافي باش الحساب يكون صحيح'),
            _tip('⚠️', 'مهم:', 'ما تنساش تحسب الديون والقرعة لي عندك'),
          ]),
        ),
      ),
      _NavBar(children: [
        SecondaryButton(label: '→ السابق', onPressed: onBack),
        const SizedBox(width: 10),
        Expanded(child: PrimaryButton(label: 'التالي ←', onPressed: onNext)),
      ]),
    ]);
  }

  Widget _tip(String icon, String bold, String rest) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.off,
          border: Border.all(color: AppColors.border),
          borderRadius: BorderRadius.circular(AppRadius.sm),
        ),
        child: Row(children: [
          Text(icon, style: const TextStyle(fontSize: 18)),
          const SizedBox(width: 10),
          Expanded(
            child: Text.rich(TextSpan(children: [
              TextSpan(text: '$bold ',
                  style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.text, fontSize: 11.5)),
              TextSpan(text: rest,
                  style: const TextStyle(color: AppColors.text2, fontSize: 11.5, height: 1.5)),
            ])),
          ),
        ]),
      );
}

// ───────────────────────── STEP 3: CATEGORIES ─────────────────────────

class _StepCategories extends ConsumerWidget {
  final VoidCallback onBack, onNext;
  const _StepCategories({required this.onBack, required this.onNext});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final active = ref.watch(nqdiProvider).activeCategoryIds;
    final ctrl = ref.read(nqdiProvider.notifier);

    Widget bucket(String tag, Color bg, Color fg, String note, CategoryBucket b) {
      final cats = kCategories.where((c) => c.bucket == b).toList();
      return Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(100)),
              child: Text(tag, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: fg)),
            ),
            const SizedBox(width: 8),
            Text(note, style: const TextStyle(fontSize: 11, color: AppColors.text3)),
          ]),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 2, shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 3.4, mainAxisSpacing: 8, crossAxisSpacing: 8,
            children: cats.map((c) {
              final checked = active.contains(c.id);
              final danger = c.isDanger;
              return InkWell(
                onTap: () => ctrl.toggleCategory(c.id),
                borderRadius: BorderRadius.circular(AppRadius.sm),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: checked ? (danger ? AppColors.redXl : AppColors.greenXl) : AppColors.white,
                    border: Border.all(
                        color: checked ? (danger ? AppColors.red : AppColors.green) : AppColors.border,
                        width: 2),
                    borderRadius: BorderRadius.circular(AppRadius.sm),
                  ),
                  child: Row(children: [
                    Container(
                      width: 20, height: 20,
                      decoration: BoxDecoration(
                        color: checked ? (danger ? AppColors.red : AppColors.green) : AppColors.white,
                        border: Border.all(color: AppColors.border2, width: 2),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: checked ? const Icon(Icons.check, size: 13, color: Colors.white) : null,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(c.name,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                    ),
                    Text(c.icon, style: const TextStyle(fontSize: 20)),
                  ]),
                ),
              );
            }).toList(),
          ),
        ]),
      );
    }

    return Column(children: [
      _TopBar(title: 'شنو كتخسر فيه؟', subtitle: 'عزل المصاريف ديالك كل شهر', onBack: onBack),
      Expanded(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          child: Column(children: [
            const StepBar(step: 3),
            const SizedBox(height: 16),
            bucket('📌 ثابتة', const Color(0xFFEEF2FF), const Color(0xFF4338CA), 'كل شهر كيف كيف', CategoryBucket.fixed),
            bucket('🔄 متغيرة', AppColors.greenL, AppColors.greenD, 'بحسب الأسبوع والحال', CategoryBucket.variable),
            bucket('🚨 خطر', AppColors.redL, AppColors.redD, 'كتبلّع الفلوس بلا ما تحس', CategoryBucket.danger),
          ]),
        ),
      ),
      _NavBar(children: [
        SecondaryButton(label: '→ السابق', onPressed: onBack),
        const SizedBox(width: 10),
        Expanded(child: PrimaryButton(label: 'التالي ←', onPressed: onNext)),
      ]),
    ]);
  }
}

// ───────────────────────── STEP 4: ESTIMATES ─────────────────────────

class _StepEstimates extends ConsumerStatefulWidget {
  final Map<String, TextEditingController> estControllers;
  final VoidCallback onBack, onFinish;
  const _StepEstimates({required this.estControllers, required this.onBack, required this.onFinish});

  @override
  ConsumerState<_StepEstimates> createState() => _StepEstimatesState();
}

class _StepEstimatesState extends ConsumerState<_StepEstimates> {
  double _total = 0;

  void _recompute() {
    double t = 0;
    for (final c in widget.estControllers.values) {
      t += double.tryParse(c.text) ?? 0;
    }
    setState(() => _total = t);
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(nqdiProvider);
    final active = s.activeCategories;
    final over = _total > s.salary;

    return Column(children: [
      _TopBar(title: 'تقدير المصاريف', subtitle: 'شحال ناوي تخسر في كل فئة؟', onBack: widget.onBack),
      Expanded(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
          child: Column(children: [
            const StepBar(step: 4),
            const SizedBox(height: 16),
            if (over)
              Container(
                margin: const EdgeInsets.only(bottom: 14),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.yellowXl,
                  border: Border.all(color: AppColors.yellow, width: 1.5),
                  borderRadius: BorderRadius.circular(AppRadius.sm),
                ),
                child: const Row(children: [
                  Icon(Icons.warning_amber_rounded, color: AppColors.yellowD, size: 20),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text('انتبه! مجموع التقديرات كبر من الصالير ديالك',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.yellowD)),
                  ),
                ]),
              ),
            ...active.map((c) => Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    border: Border.all(color: AppColors.border, width: 1.5),
                    borderRadius: BorderRadius.circular(AppRadius.sm),
                  ),
                  child: Row(children: [
                    Text(c.icon, style: const TextStyle(fontSize: 22)),
                    const SizedBox(width: 12),
                    Expanded(child: Text(c.name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700))),
                    SizedBox(
                      width: 90,
                      child: TextField(
                        controller: widget.estControllers[c.id],
                        keyboardType: TextInputType.number,
                        textAlign: TextAlign.center,
                        onChanged: (_) => _recompute(),
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                        decoration: InputDecoration(
                          hintText: '0', isDense: true,
                          contentPadding: const EdgeInsets.symmetric(vertical: 8),
                          filled: true, fillColor: AppColors.off,
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: const BorderSide(color: AppColors.border, width: 1.5),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide(color: c.isDanger ? AppColors.red : AppColors.green, width: 1.5),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Text('درهم', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.text3)),
                  ]),
                )),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [AppColors.greenXl, Color(0xFFF0FDF9)]),
                border: Border.all(color: AppColors.greenL),
                borderRadius: BorderRadius.circular(AppRadius.sm),
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('مجموع التقديرات',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.text2)),
                  Text('من ${NqdiController.fmt(s.salary)} درهم',
                      style: const TextStyle(fontSize: 10, color: AppColors.text3)),
                ]),
                Text('${NqdiController.fmt(_total)} درهم',
                    style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w900,
                        color: over ? AppColors.red : AppColors.green)),
              ]),
            ),
          ]),
        ),
      ),
      _NavBar(children: [
        SecondaryButton(label: '→ السابق', onPressed: widget.onBack),
        const SizedBox(width: 10),
        Expanded(child: PrimaryButton(label: 'تأكيد 🚀', onPressed: widget.onFinish)),
      ]),
    ]);
  }
}

// ─────────────────────────── SHARED CHROME ───────────────────────────

class _TopBar extends StatelessWidget {
  final String title, subtitle;
  final VoidCallback onBack;
  const _TopBar({required this.title, required this.subtitle, required this.onBack});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(22, 20, 22, 18),
      decoration: const BoxDecoration(
        color: AppColors.white,
        border: Border(bottom: BorderSide(color: AppColors.border)),
      ),
      child: Row(children: [
        InkWell(
          onTap: onBack,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              color: AppColors.off, border: Border.all(color: AppColors.border),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.chevron_right, color: AppColors.text2),
          ),
        ),
        const SizedBox(width: 14),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.text3)),
        ]),
      ]),
    );
  }
}

class _NavBar extends StatelessWidget {
  final List<Widget> children;
  const _NavBar({required this.children});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
      decoration: const BoxDecoration(
        color: AppColors.white,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: Row(children: children),
    );
  }
}
