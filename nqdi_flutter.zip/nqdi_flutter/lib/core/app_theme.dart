// lib/core/app_theme.dart
//
// Central design system for Nqdi. Mirrors the CSS custom properties from the
// original web app (the `:root { --green ... }` block) so the mobile build is
// pixel-faithful to the brand. All colors, radii and shadows live here so the
// rest of the app never hard-codes a hex value.

import 'package:flutter/material.dart';

/// Brand palette. Names map 1:1 to the original CSS variables.
class AppColors {
  AppColors._();

  static const white = Color(0xFFFFFFFF);
  static const off = Color(0xFFF7F8FA);
  static const off2 = Color(0xFFEEF0F4);
  static const border = Color(0xFFE4E8EE);
  static const border2 = Color(0xFFD1D8E2);

  static const text = Color(0xFF0F1923);
  static const text2 = Color(0xFF4A5568);
  static const text3 = Color(0xFF9AA3B0);

  static const green = Color(0xFF10B981);
  static const greenL = Color(0xFFD1FAE5);
  static const greenD = Color(0xFF059669);
  static const greenXl = Color(0xFFECFDF5);

  static const yellow = Color(0xFFF59E0B);
  static const yellowL = Color(0xFFFEF3C7);
  static const yellowD = Color(0xFFD97706);
  static const yellowXl = Color(0xFFFFFBEB);

  static const red = Color(0xFFEF4444);
  static const redL = Color(0xFFFEE2E2);
  static const redD = Color(0xFFDC2626);
  static const redXl = Color(0xFFFFF5F5);

  static const blue = Color(0xFF3B82F6);
  static const blueL = Color(0xFFDBEAFE);
  static const purple = Color(0xFF7C3AED);

  /// Pie/category chart palette (matches PIE_COLORS in the web build).
  static const List<Color> chart = [
    Color(0xFF10B981), Color(0xFF3B82F6), Color(0xFFF59E0B), Color(0xFF8B5CF6),
    Color(0xFFEF4444), Color(0xFF06B6D4), Color(0xFF84CC16), Color(0xFFF97316),
    Color(0xFFEC4899), Color(0xFF14B8A6), Color(0xFF6366F1), Color(0xFFA855F7),
    Color(0xFF22C55E), Color(0xFFEAB308), Color(0xFFE11D48), Color(0xFF0EA5E9),
  ];
}

/// Spacing & radius tokens.
class AppRadius {
  AppRadius._();
  static const double r = 16;
  static const double sm = 10;
  static const double xs = 8;
}

/// Builds the global Material 3 theme. The app forces RTL + the Cairo
/// typeface to match the Arabic / Darija interface.
class AppTheme {
  AppTheme._();

  static ThemeData light() {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.green,
        primary: AppColors.green,
        surface: AppColors.white,
        brightness: Brightness.light,
      ),
      scaffoldBackgroundColor: AppColors.white,
      fontFamily: 'Cairo',
    );

    return base.copyWith(
      textTheme: base.textTheme.apply(
        bodyColor: AppColors.text,
        displayColor: AppColors.text,
      ),
      splashFactory: InkRipple.splashFactory,
    );
  }
}
