// lib/widgets/tabs/prosperity_tab.dart
//
// "الازدهار" — a coming-soon teaser with an auto-rotating tips ticker.

import 'dart:async';
import 'package:flutter/material.dart';

import '../../core/app_theme.dart';
import '../../models/models.dart';

class ProsperityTab extends StatefulWidget {
  const ProsperityTab({super.key});
  @override
  State<ProsperityTab> createState() => _ProsperityTabState();
}

class _ProsperityTabState extends State<ProsperityTab> {
  int _tip = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (mounted) setState(() => _tip = (_tip + 1) % kTips.length);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [Color(0xFFF0FDF4), Color(0xFFFFFBEB), Color(0xFFF0F9FF)],
        ),
      ),
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('🚀', style: TextStyle(fontSize: 72)),
            const SizedBox(height: 16),
            const Text('قريباً !!',
                style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: AppColors.text)),
            const SizedBox(height: 8),
            const Text('قريباً غيجي شي كبير 👀\nاستنى معانا',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, color: AppColors.text3, height: 1.6)),
            const SizedBox(height: 32),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.white, border: Border.all(color: AppColors.border, width: 1.5),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(children: [
                const Text('🌱', style: TextStyle(fontSize: 28)),
                const SizedBox(height: 10),
                const Text('العساس – نصائح الازدهار',
                    style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800,
                        color: AppColors.text3, letterSpacing: 0.8)),
                const SizedBox(height: 8),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 400),
                  child: Text(kTips[_tip],
                      key: ValueKey(_tip), textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600,
                          color: AppColors.text2, height: 1.7)),
                ),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  for (var i = 0; i < kTips.length; i++)
                    GestureDetector(
                      onTap: () => setState(() => _tip = i),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.symmetric(horizontal: 2.5),
                        width: i == _tip ? 18 : 6, height: 6,
                        decoration: BoxDecoration(
                          color: i == _tip ? AppColors.green : AppColors.border2,
                          borderRadius: BorderRadius.circular(100),
                        ),
                      ),
                    ),
                ]),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
