// lib/widgets/tabs/month_tab.dart
//
// Monthly overview: spending ratios, key stats, estimate-vs-actual bars,
// the debt ledger (سالوني / كنسال) and an expandable per-day history.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/app_theme.dart';
import '../../models/models.dart';
import '../../providers/app_state.dart';
import '../common.dart';

class MonthTab extends ConsumerStatefulWidget {
  const MonthTab({super.key});
  @override
  ConsumerState<MonthTab> createState() => _MonthTabState();
}

class _MonthTabState extends ConsumerState<MonthTab> {
  bool _iOweTab = true;
  bool _historyOpen = false;
  final _debtName = TextEditingController();
  final _debtAmt = TextEditingController();

  @override
  void dispose() {
    _debtName.dispose();
    _debtAmt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(nqdiProvider);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        _header(),
        _progressCard(s),
        _statsCard(s),
        _comparisonCard(s),
        _debtCard(s),
        _historyToggle(s),
      ],
    );
  }

  Widget _header() => const Padding(
        padding: EdgeInsets.only(bottom: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('📅 الشهر', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          Text('ملخص المصاريف الشهرية', style: TextStyle(fontSize: 11, color: AppColors.text3)),
        ]),
      );

  Widget _progressBar(String name, double pct, Color color) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(name, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
          Text('${pct.round()}%',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: color)),
        ]),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(100),
          child: LinearProgressIndicator(
            value: (pct / 100).clamp(0, 1),
            minHeight: 8, backgroundColor: AppColors.off2,
            valueColor: AlwaysStoppedAnimation(color),
          ),
        ),
      ]),
    );
  }

  Widget _progressCard(NqdiState s) {
    final pctTotal = s.salary > 0 ? s.totalSpent / s.salary * 100 : 0.0;
    final pctFixed = s.salary > 0 ? s.fixedSpent / s.salary * 100 : 0.0;
    final pctVar = s.salary > 0 ? s.variableSpent / s.salary * 100 : 0.0;
    final pctDanger = s.salary > 0 ? s.dangerSpent / s.salary * 100 : 0.0;
    return _card(child: Column(children: [
      const Align(alignment: Alignment.centerRight, child: SectionHeader('نسب الإنفاق')),
      _progressBar('إجمالي الميزانية', pctTotal, AppColors.text),
      _progressBar('المصاريف الثابتة', pctFixed, AppColors.blue),
      _progressBar('المصاريف المتغيرة', pctVar, AppColors.green),
      _progressBar('البلية والعادات', pctDanger, AppColors.red),
    ]));
  }

  Widget _statRow(String icon, Color bg, String name, String val, Color valColor) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Row(children: [
            Container(
              width: 32, height: 32,
              decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)),
              child: Center(child: Text(icon, style: const TextStyle(fontSize: 16))),
            ),
            const SizedBox(width: 10),
            Text(name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
          ]),
          Text(val, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: valColor)),
        ]),
      );

  Widget _statsCard(NqdiState s) => _card(child: Column(children: [
        _statRow('💼', const Color(0xFFEEF2FF), 'الميزانية الأساسية',
            '${NqdiController.fmt(s.salary)} درهم', AppColors.text),
        const Divider(height: 1, color: AppColors.border),
        _statRow('💸', AppColors.redXl, 'إجمالي ما صرفتي',
            '${NqdiController.fmt(s.totalSpent)} درهم', AppColors.red),
        const Divider(height: 1, color: AppColors.border),
        _statRow('💚', AppColors.greenXl, 'المتبقي هاد الشهر',
            '${NqdiController.fmt(s.remaining)} درهم', AppColors.green),
        const Divider(height: 1, color: AppColors.border),
        _statRow('🎯', AppColors.yellowXl, 'البونص المجمع',
            '${NqdiController.fmt(s.bonusTotal)} درهم', AppColors.yellowD),
      ]));

  Widget _comparisonCard(NqdiState s) {
    final cats = s.activeCategories
        .where((c) => (s.categorySpent[c.id] ?? 0) > 0 || (s.estimates[c.id] ?? 0) > 0)
        .toList();
    final maxVal = cats.isEmpty
        ? 1.0
        : cats
            .map((c) => [s.categorySpent[c.id] ?? 0, s.estimates[c.id] ?? 0].reduce((a, b) => a > b ? a : b))
            .reduce((a, b) => a > b ? a : b);

    return _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SectionHeader('المقارنة: التقدير مقابل الواقع'),
      if (cats.isEmpty)
        const Center(
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: 12),
            child: Column(children: [
              Text('📊', style: TextStyle(fontSize: 28)),
              SizedBox(height: 8),
              Text('ما زال ما كاين معطية', style: TextStyle(fontSize: 13, color: AppColors.text3)),
            ]),
          ),
        )
      else
        ...cats.map((c) {
          final spent = s.categorySpent[c.id] ?? 0;
          final est = s.estimates[c.id] ?? 0;
          final over = spent > est && est > 0;
          return Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('${c.icon} ${c.name}',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                Row(children: [
                  Text('تقدير: ${NqdiController.fmt(est)}',
                      style: const TextStyle(fontSize: 10, color: AppColors.text3, fontWeight: FontWeight.w600)),
                  const SizedBox(width: 10),
                  Text('فعلي: ${NqdiController.fmt(spent)}',
                      style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700,
                          color: over ? AppColors.red : AppColors.greenD)),
                ]),
              ]),
              const SizedBox(height: 5),
              Stack(children: [
                Container(height: 8,
                    decoration: BoxDecoration(color: AppColors.off2, borderRadius: BorderRadius.circular(100))),
                FractionallySizedBox(
                  widthFactor: (est / maxVal).clamp(0, 1),
                  child: Container(height: 8,
                      decoration: BoxDecoration(color: AppColors.text3.withValues(alpha: 0.5),
                          borderRadius: BorderRadius.circular(100))),
                ),
                FractionallySizedBox(
                  widthFactor: (spent / maxVal).clamp(0, 1),
                  child: Container(height: 8,
                      decoration: BoxDecoration(
                          color: over ? AppColors.red : AppColors.green,
                          borderRadius: BorderRadius.circular(100))),
                ),
              ]),
            ]),
          );
        }),
    ]));
  }

  Widget _debtCard(NqdiState s) {
    final list = _iOweTab ? s.debtsIOwe : s.debtsOwedToMe;
    return _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SectionHeader('💳 سالني ونسالك'),
      Row(children: [
        _debtTab('😬 سالوني (عندي ديون)', _iOweTab, () => setState(() => _iOweTab = true), AppColors.red, AppColors.redXl, AppColors.redD),
        const SizedBox(width: 6),
        _debtTab('😎 كنسال (عندهم دِيني)', !_iOweTab, () => setState(() => _iOweTab = false), AppColors.green, AppColors.greenXl, AppColors.greenD),
      ]),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
          child: TextField(
            controller: _debtName,
            decoration: _debtInputDeco(_iOweTab ? 'مول الحانوت، صاحب...' : 'الصاحب، خوك...'),
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
          ),
        ),
        const SizedBox(width: 6),
        SizedBox(
          width: 80,
          child: TextField(
            controller: _debtAmt,
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            decoration: _debtInputDeco('0'),
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
          ),
        ),
        const SizedBox(width: 6),
        InkWell(
          onTap: () {
            final res = ref.read(nqdiProvider.notifier).addDebt(
                  iOwe: _iOweTab,
                  name: _debtName.text,
                  amount: double.tryParse(_debtAmt.text) ?? 0,
                );
            showToast(context, res);
            if (res.status == ActionStatus.success) {
              _debtName.clear();
              _debtAmt.clear();
            }
          },
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 40, height: 40,
            decoration: BoxDecoration(color: AppColors.green, borderRadius: BorderRadius.circular(8)),
            child: const Icon(Icons.add, color: Colors.white),
          ),
        ),
      ]),
      const SizedBox(height: 10),
      if (list.isEmpty)
        Center(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text(_iOweTab ? 'ما عندك ديون 👍' : 'ما عندك ناس كتسالك 😶',
                style: const TextStyle(fontSize: 12, color: AppColors.text3)),
          ),
        )
      else
        ...list.map((d) => Container(
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(color: AppColors.off, borderRadius: BorderRadius.circular(8)),
              child: Row(children: [
                Expanded(child: Text(d.name, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700))),
                Text('${NqdiController.fmt(d.amount)} درهم',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800,
                        color: _iOweTab ? AppColors.red : AppColors.greenD)),
                const SizedBox(width: 8),
                InkWell(
                  onTap: () => ref.read(nqdiProvider.notifier).removeDebt(iOwe: _iOweTab, id: d.id),
                  child: Container(
                    width: 24, height: 24,
                    decoration: BoxDecoration(color: AppColors.redL, borderRadius: BorderRadius.circular(6)),
                    child: const Icon(Icons.close, size: 14, color: AppColors.red),
                  ),
                ),
              ]),
            )),
    ]));
  }

  Widget _debtTab(String label, bool active, VoidCallback onTap, Color border, Color bg, Color fg) => Expanded(
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: active ? bg : AppColors.white,
              border: Border.all(color: active ? border : AppColors.border, width: 1.5),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(label, textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
                    color: active ? fg : AppColors.text3)),
          ),
        ),
      );

  InputDecoration _debtInputDeco(String hint) => InputDecoration(
        hintText: hint, isDense: true, filled: true, fillColor: AppColors.off,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.border, width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.green, width: 1.5),
        ),
      );

  Widget _historyToggle(NqdiState s) => Column(children: [
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [AppColors.blue, Color(0xFF2563EB)]),
            borderRadius: BorderRadius.circular(AppRadius.sm),
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(AppRadius.sm),
              onTap: () => setState(() => _historyOpen = !_historyOpen),
              child: const Padding(
                padding: EdgeInsets.all(14),
                child: Center(
                  child: Text('📆 رؤية سجل الأيام',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Colors.white)),
                ),
              ),
            ),
          ),
        ),
        if (_historyOpen) ...[
          const SizedBox(height: 12),
          ...List.generate(kTotalDays, (i) => _dayRow(s, i + 1)),
        ],
      ]);

  Widget _dayRow(NqdiState s, int day) {
    final dh = s.dayHistory[day];
    final isToday = day == s.currentDay;
    final spent = dh?.total ?? 0;
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      decoration: BoxDecoration(
        color: AppColors.white, border: Border.all(color: AppColors.border, width: 1.5),
        borderRadius: BorderRadius.circular(AppRadius.sm),
      ),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 14),
        shape: const Border(), collapsedShape: const Border(),
        leading: Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
            color: isToday ? AppColors.green : AppColors.off,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Center(
            child: Text('$day',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900,
                    color: isToday ? Colors.white : AppColors.text)),
          ),
        ),
        title: Text(isToday ? 'اليوم الحالي' : 'يوم $day',
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
        subtitle: Text(
            dh != null && dh.logs.isNotEmpty ? '${dh.logs.length} مصروف مسجل' : 'ما صرفتي والو',
            style: const TextStyle(fontSize: 10, color: AppColors.text3)),
        trailing: Text(spent > 0 ? '${NqdiController.fmt(spent)} درهم' : '—',
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppColors.text2)),
        children: [
          if (dh != null && dh.logs.isNotEmpty)
            ...dh.logs.map((l) => Container(
                  color: AppColors.off,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  child: Row(children: [
                    Text(l.categoryIcon, style: const TextStyle(fontSize: 14)),
                    const SizedBox(width: 8),
                    Expanded(child: Text(l.categoryName,
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.text2))),
                    Text('-${NqdiController.fmt(l.amount)} درهم',
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.red)),
                  ]),
                ))
          else
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text('ما كاين شي فهاد اليوم',
                  style: TextStyle(fontSize: 12, color: AppColors.text3)),
            ),
        ],
      ),
    );
  }

  Widget _card({required Widget child}) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppColors.white, border: Border.all(color: AppColors.border, width: 1.5),
          borderRadius: BorderRadius.circular(20),
        ),
        child: child,
      );
}
