// lib/widgets/tabs/today_tab.dart
//
// The main daily cockpit: profile widget, budget chips, the live tree,
// daily allowance, the 15% savings engine card, the نهار بيض challenge,
// the لیوم قاومت resistance button, the expense logger, recent history,
// and a pie breakdown.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';

import '../../core/app_theme.dart';
import '../../models/models.dart';
import '../../painters/tree_painter.dart';
import '../../providers/app_state.dart';
import '../common.dart';

class TodayTab extends ConsumerStatefulWidget {
  const TodayTab({super.key});
  @override
  ConsumerState<TodayTab> createState() => _TodayTabState();
}

class _TodayTabState extends ConsumerState<TodayTab> {
  final _expense = TextEditingController();

  @override
  void dispose() {
    _expense.dispose();
    super.dispose();
  }

  void _log() {
    final amt = double.tryParse(_expense.text) ?? 0;
    final res = ref.read(nqdiProvider.notifier).logExpense(amt);
    showToast(context, res);
    if (res.status == ActionStatus.success || res.status == ActionStatus.danger) {
      _expense.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(nqdiProvider);
    final ctrl = ref.read(nqdiProvider.notifier);

    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        _profileWidget(s),
        _chips(s),
        _tree(s),
        _allowance(s),
        _quickLogRow(ctrl),
        _savingsCard(s),
        _whiteDayCard(s, ctrl),
        _piggyRow(s),
        _victoryButton(ctrl),
        _logSection(s, ctrl),
        _history(s),
        _pieSection(s),
      ],
    );
  }

  // ── Profile header card ──
  Widget _profileWidget(NqdiState s) => Container(
        margin: const EdgeInsets.fromLTRB(16, 14, 16, 0),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF0F172A), Color(0xFF1E293B)]),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [AppColors.green, AppColors.greenD]),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Center(child: Text('👤', style: TextStyle(fontSize: 22))),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('مرحباً بيك!', style: TextStyle(fontSize: 10, color: Colors.white54)),
              Text(s.fullName.isEmpty ? '—' : s.fullName,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Colors.white)),
              Text(s.phone.isEmpty ? '—' : s.phone,
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(fontSize: 11, color: Colors.white60)),
            ]),
          ),
        ]),
      );

  // ── Budget chips row ──
  Widget _chips(NqdiState s) {
    Widget chip(String lbl, String val, Color accent) => Expanded(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 4),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
            decoration: BoxDecoration(
              color: AppColors.off, border: Border.all(color: AppColors.border),
              borderRadius: BorderRadius.circular(AppRadius.sm),
            ),
            child: Column(children: [
              Text(lbl, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: AppColors.text3)),
              const SizedBox(height: 4),
              Text(val, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: accent)),
            ]),
          ),
        );
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      child: Row(children: [
        chip('الميزانية', NqdiController.fmt(s.salary), AppColors.text),
        chip('المصروف', NqdiController.fmt(s.totalSpent), AppColors.red),
        chip('المتبقي', NqdiController.fmt(s.remaining), AppColors.green),
        chip('البلية', NqdiController.fmt(s.dangerSpent), AppColors.yellowD),
      ]),
    );
  }

  // ── The tree ──
  Widget _tree(NqdiState s) {
    final pct = s.healthPct;
    final stage = stageForPct(pct);
    final border = switch (stage) {
      TreeStage.healthy || TreeStage.stable when pct >= 75 => AppColors.green,
      TreeStage.stable || TreeStage.wilting => AppColors.yellow,
      TreeStage.dead => AppColors.red,
      _ => AppColors.green,
    };
    final fill = pct >= 75 ? AppColors.greenL : pct >= 15 ? AppColors.yellowL : AppColors.redL;
    final msg = pct >= 75
        ? 'شجرتك خضرا ومزيانة! 🌳'
        : pct >= 40
            ? 'راك غادي مزيان، حضي راسك 🌿'
            : pct >= 15
                ? 'عندك! الشجرة بدات كتصفار 🍂'
                : 'الشجرة ماتت! زير السمطة 🥀';

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      decoration: BoxDecoration(
        color: fill, border: Border.all(color: border, width: 2.5),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(children: [
        ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(19)),
          child: Container(
            height: 176,
            color: Colors.white.withValues(alpha: 0.35),
            child: BudgetTree(pct: pct),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(100),
            child: LinearProgressIndicator(
              value: (pct / 100).clamp(0, 1),
              minHeight: 5,
              backgroundColor: Colors.black12,
              valueColor: AlwaysStoppedAnimation(
                  pct >= 75 ? AppColors.green : pct >= 40 ? AppColors.yellow : AppColors.red),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(msg, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.55), borderRadius: BorderRadius.circular(100)),
              child: Text('${pct.round()}%',
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
            ),
          ]),
        ),
      ]),
    );
  }

  // ── Daily allowance ──
  Widget _allowance(NqdiState s) {
    final pct = s.healthPct;
    final color = pct < 15 ? AppColors.red : pct < 40 ? AppColors.yellowD : AppColors.text;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      decoration: BoxDecoration(
        color: AppColors.white, border: Border.all(color: AppColors.border, width: 1.5),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(children: [
        const Text('اليوم مسموح ليك تخسر',
            style: TextStyle(fontSize: 11, color: AppColors.text3)),
        const SizedBox(height: 6),
        RichText(
          text: TextSpan(children: [
            TextSpan(text: NqdiController.fmt(s.dailyAllowance > 0 ? s.dailyAllowance : 0),
                style: TextStyle(fontSize: 48, fontWeight: FontWeight.w900, color: color)),
            const TextSpan(text: ' درهم',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.text2)),
          ]),
        ),
        const SizedBox(height: 6),
        Text('باقي ${s.daysLeft} يوم · المتبقي ${NqdiController.fmt(s.remaining)} درهم',
            style: const TextStyle(fontSize: 11, color: AppColors.text3)),
        const SizedBox(height: 10),
        _dayDots(s),
      ]),
    );
  }

  Widget _dayDots(NqdiState s) => Wrap(
        spacing: 3, runSpacing: 3, alignment: WrapAlignment.center,
        children: List.generate(30, (i) {
          final day = i + 1;
          final used = day < s.currentDay;
          final today = day == s.currentDay;
          return Container(
            width: today ? 9 : 7, height: today ? 9 : 7,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: today ? AppColors.text : used ? AppColors.green : AppColors.border2,
            ),
          );
        }),
      );

  // ── Quick log buttons ──
  Widget _quickLogRow(NqdiController ctrl) {
    Widget qb(int amt) => Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: OutlinedButton(
              onPressed: () {
                final res = ctrl.logExpense(amt.toDouble());
                showToast(context, res);
              },
              style: OutlinedButton.styleFrom(
                backgroundColor: AppColors.off,
                foregroundColor: AppColors.text2,
                side: const BorderSide(color: AppColors.border, width: 1.5),
                padding: const EdgeInsets.symmetric(vertical: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: Text('+$amt درهم',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
            ),
          ),
        );
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
      child: Row(children: [qb(2), qb(5), qb(10), qb(20)]),
    );
  }

  // ── 15% savings engine card ──
  Widget _savingsCard(NqdiState s) => Container(
        margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
              begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: [AppColors.green, AppColors.greenD]),
          borderRadius: BorderRadius.circular(20),
          boxShadow: const [BoxShadow(color: Color(0x4D10B981), blurRadius: 16, offset: Offset(0, 4))],
        ),
        child: Column(children: [
          Row(children: [
            Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                color: Colors.white24, borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white30, width: 1.5),
              ),
              child: const Center(child: Text('🎯', style: TextStyle(fontSize: 22))),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('هدف الادخار',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: Colors.white)),
                Text('15% من المتبقي بعد المصاريف الثابتة',
                    style: TextStyle(fontSize: 10.5, color: Colors.white70)),
              ]),
            ),
          ]),
          const SizedBox(height: 14),
          RichText(
            text: TextSpan(children: [
              TextSpan(text: NqdiController.fmt(s.savingsGoal),
                  style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w900, color: Colors.white)),
              const TextSpan(text: ' درهم',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white70)),
            ]),
          ),
          const SizedBox(height: 14),
          Row(children: [
            _svBd('الميزانية الصافية', NqdiController.fmt(s.fluidBudget)),
            const SizedBox(width: 8),
            _svBd('للمصروف بعد الادخار', NqdiController.fmt(s.spendableAfterSavings)),
          ]),
        ]),
      );

  Widget _svBd(String lbl, String val) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.14),
            borderRadius: BorderRadius.circular(AppRadius.xs),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(lbl, style: const TextStyle(fontSize: 9, color: Colors.white70)),
            const SizedBox(height: 2),
            Text('$val درهم',
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Colors.white)),
          ]),
        ),
      );

  // ── White day challenge ──
  Widget _whiteDayCard(NqdiState s, NqdiController ctrl) => Container(
        margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFFF0F9FF), Color(0xFFE0F2FE)]),
          border: Border.all(color: const Color(0xFFBAE6FD), width: 1.5),
          borderRadius: BorderRadius.circular(AppRadius.sm),
        ),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('☀️ تحدي نهار بيض',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
              Text(s.whiteDayOn ? 'تحدي فاعل! بقا ما تخسر والو 💪' : 'وعد روحك: ما تخسر والو اليوم',
                  style: const TextStyle(fontSize: 10, color: AppColors.text3)),
            ]),
          ),
          Switch(
            value: s.whiteDayOn,
            activeThumbColor: AppColors.green,
            onChanged: (v) => showToast(context, ctrl.toggleWhiteDay(v)),
          ),
        ]),
      );

  // ── Piggy row (today's surplus/deficit + spent) ──
  Widget _piggyRow(NqdiState s) {
    final diff = s.todayDiff;
    final surplus = diff >= 0;
    Widget card1 = Expanded(
      child: Container(
        margin: const EdgeInsets.only(right: 4),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: surplus ? AppColors.greenXl : AppColors.redXl,
          border: Border.all(color: surplus ? AppColors.green : AppColors.red, width: 1.5),
          borderRadius: BorderRadius.circular(AppRadius.sm),
        ),
        child: Column(children: [
          const Text('🐷', style: TextStyle(fontSize: 24)),
          const SizedBox(height: 4),
          const Text('صندوق النهار',
              style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: AppColors.text3)),
          Text('${surplus ? '+' : '-'}${NqdiController.fmt(diff.abs())} درهم',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900,
                  color: surplus ? AppColors.green : AppColors.red)),
          Text(surplus ? 'وفرت اليوم 👏' : 'تجاوزت اليوم ⚠️',
              style: const TextStyle(fontSize: 9, color: AppColors.text3)),
        ]),
      ),
    );
    Widget card2 = Expanded(
      child: Container(
        margin: const EdgeInsets.only(left: 4),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.white, border: Border.all(color: AppColors.border, width: 1.5),
          borderRadius: BorderRadius.circular(AppRadius.sm),
        ),
        child: Column(children: [
          const Text('📅', style: TextStyle(fontSize: 24)),
          const SizedBox(height: 4),
          const Text('صرفت اليوم',
              style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: AppColors.text3)),
          Text('${NqdiController.fmt(s.todaySpent)} درهم',
              style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: AppColors.text2)),
          Text(s.todaySpent == 0 ? 'ما صرفتي والو' : 'صرفتي اليوم',
              style: const TextStyle(fontSize: 9, color: AppColors.text3)),
        ]),
      ),
    );
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Row(children: [card1, card2]),
    );
  }

  // ── Victory button ──
  Widget _victoryButton(NqdiController ctrl) => Container(
        margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [AppColors.purple, Color(0xFF5B21B6)]),
          borderRadius: BorderRadius.circular(AppRadius.sm),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(AppRadius.sm),
            onTap: () {
              final res = ctrl.claimVictory();
              showToast(context, res);
              if (res.status == ActionStatus.success) _showVictoryDialog(res.message);
            },
            child: const Padding(
              padding: EdgeInsets.all(13),
              child: Center(
                child: Text('🏆 اليوم قاومت! كليك باش تضيف لصندوق النهار',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Colors.white)),
              ),
            ),
          ),
        ),
      );

  void _showVictoryDialog(String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('🏆', style: TextStyle(fontSize: 64)),
          const SizedBox(height: 12),
          const Text('عاش! قاومت اليوم! 💪',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.green)),
          const SizedBox(height: 8),
          Text(msg, textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 14, color: AppColors.text2)),
        ]),
        actions: [
          Center(
            child: PrimaryButton(label: 'شكراً 💪', onPressed: () => Navigator.pop(context)),
          ),
        ],
      ),
    );
  }

  // ── Log expense section ──
  Widget _logSection(NqdiState s, NqdiController ctrl) => Container(
        margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppColors.white, border: Border.all(color: AppColors.border, width: 1.5),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SectionHeader('زيد مصروف'),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _expense,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                onSubmitted: (_) => _log(),
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
                decoration: InputDecoration(
                  hintText: 'المبلغ...', filled: true, fillColor: AppColors.off,
                  contentPadding: const EdgeInsets.symmetric(vertical: 14),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(AppRadius.sm),
                    borderSide: const BorderSide(color: AppColors.border, width: 1.5),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(AppRadius.sm),
                    borderSide: const BorderSide(color: AppColors.green, width: 1.5),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [AppColors.green, AppColors.greenD]),
                borderRadius: BorderRadius.circular(AppRadius.sm),
              ),
              child: const Center(
                  child: Text('درهم',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13))),
            ),
          ]),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 3, shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 1.9, mainAxisSpacing: 6, crossAxisSpacing: 6,
            children: s.activeCategories.map((c) {
              final sel = s.selectedCategoryId == c.id;
              return InkWell(
                onTap: () => ctrl.selectLogCategory(sel ? null : c.id),
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  decoration: BoxDecoration(
                    color: sel ? (c.isDanger ? AppColors.redXl : AppColors.greenXl) : AppColors.off,
                    border: Border.all(
                        color: sel ? (c.isDanger ? AppColors.red : AppColors.green) : AppColors.border,
                        width: 1.5),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(c.icon, style: const TextStyle(fontSize: 18)),
                    const SizedBox(height: 2),
                    Text(c.name,
                        textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 9, fontWeight: FontWeight.w700,
                            color: sel ? (c.isDanger ? AppColors.redD : AppColors.greenD) : AppColors.text2)),
                  ]),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: PrimaryButton(label: 'قيّد المصروف ✓', onPressed: _log),
          ),
        ]),
      );

  // ── Recent history ──
  Widget _history(NqdiState s) {
    final items = s.logs.take(20).toList();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SectionHeader('آخر المصاريف'),
        if (items.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 28),
            child: Center(
              child: Column(children: [
                Text('📭', style: TextStyle(fontSize: 36)),
                SizedBox(height: 8),
                Text('ما زال ما دخلتي حتى مصروف',
                    style: TextStyle(fontSize: 13, color: AppColors.text3)),
              ]),
            ),
          )
        else
          ...items.map((l) => Container(
                margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  color: l.danger ? AppColors.redXl : AppColors.white,
                  border: Border.all(color: l.danger ? AppColors.redL : AppColors.border),
                  borderRadius: BorderRadius.circular(AppRadius.sm),
                ),
                child: Row(children: [
                  Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      color: l.danger ? const Color(0x14EF4444) : AppColors.off,
                      shape: BoxShape.circle,
                    ),
                    child: Center(child: Text(l.categoryIcon, style: const TextStyle(fontSize: 18))),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(l.categoryName, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
                      Text('يوم ${l.day} · ${l.time}',
                          style: const TextStyle(fontSize: 10, color: AppColors.text3)),
                    ]),
                  ),
                  Text('-${NqdiController.fmt(l.amount)} درهم',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.red)),
                ]),
              )),
      ]),
    );
  }

  // ── Pie breakdown ──
  Widget _pieSection(NqdiState s) {
    final spent = s.activeCategories
        .where((c) => (s.categorySpent[c.id] ?? 0) > 0)
        .toList()
      ..sort((a, b) => (s.categorySpent[b.id] ?? 0).compareTo(s.categorySpent[a.id] ?? 0));
    final top = spent.take(8).toList();

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SectionHeader('توزيع المصاريف'),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: AppColors.white, border: Border.all(color: AppColors.border, width: 1.5),
            borderRadius: BorderRadius.circular(20),
          ),
          child: top.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Column(children: [
                      Text('🥧', style: TextStyle(fontSize: 28)),
                      SizedBox(height: 8),
                      Text('ما زال ما كاين معطية', style: TextStyle(fontSize: 13, color: AppColors.text3)),
                    ]),
                  ),
                )
              : Row(children: [
                  SizedBox(
                    width: 120, height: 120,
                    child: PieChart(PieChartData(
                      sectionsSpace: 2, centerSpaceRadius: 34,
                      sections: [
                        for (var i = 0; i < top.length; i++)
                          PieChartSectionData(
                            value: s.categorySpent[top[i].id] ?? 0,
                            color: AppColors.chart[i % AppColors.chart.length],
                            radius: 22, showTitle: false,
                          ),
                      ],
                    )),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      children: [
                        for (var i = 0; i < top.length; i++)
                          _legend(top[i], AppColors.chart[i % AppColors.chart.length],
                              s.categorySpent[top[i].id] ?? 0,
                              top.fold(0.0, (sum, c) => sum + (s.categorySpent[c.id] ?? 0))),
                      ],
                    ),
                  ),
                ]),
        ),
      ]),
    );
  }

  Widget _legend(ExpenseCategory c, Color color, double amt, double total) => Padding(
        padding: const EdgeInsets.only(bottom: 7),
        child: Row(children: [
          Container(width: 9, height: 9,
              decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(3))),
          const SizedBox(width: 8),
          Expanded(
            child: Text('${c.icon} ${c.name}',
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
          ),
          Text('${total > 0 ? (amt / total * 100).round() : 0}%',
              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.text2)),
        ]),
      );
}
