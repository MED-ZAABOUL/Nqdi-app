// lib/widgets/tabs/profile_tab.dart
//
// "الملف الشخصي" — profile hero, editable info form (with name/phone
// validation), resistance statistics, and a destructive full-reset action.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/app_theme.dart';
import '../../providers/app_state.dart';
import '../../screens/onboarding_screen.dart';
import '../common.dart';

class ProfileTab extends ConsumerStatefulWidget {
  const ProfileTab({super.key});
  @override
  ConsumerState<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends ConsumerState<ProfileTab> {
  late final TextEditingController _first;
  late final TextEditingController _last;
  late final TextEditingController _phone;
  bool _phoneErr = false;
  bool _synced = false;

  @override
  void initState() {
    super.initState();
    _first = TextEditingController();
    _last = TextEditingController();
    _phone = TextEditingController();
  }

  @override
  void dispose() {
    _first.dispose();
    _last.dispose();
    _phone.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(nqdiProvider);
    // Seed controllers once from state.
    if (!_synced) {
      _first.text = s.firstName;
      _last.text = s.lastName;
      _phone.text = s.phone;
      _synced = true;
    }

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        _hero(s),
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 20, 18, 20),
          child: Column(children: [
            _editCard(),
            _resistCard(s),
            _resetCard(),
          ]),
        ),
      ],
    );
  }

  Widget _hero(NqdiState s) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight, end: Alignment.bottomLeft,
            colors: [AppColors.green, AppColors.greenD, Color(0xFF047857)],
          ),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            width: 72, height: 72,
            decoration: BoxDecoration(
              color: Colors.white24, borderRadius: BorderRadius.circular(24),
              border: Border.all(color: Colors.white30, width: 2),
            ),
            child: const Center(child: Text('👤', style: TextStyle(fontSize: 32))),
          ),
          const SizedBox(height: 12),
          Text(s.fullName.isEmpty ? '—' : s.fullName,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white)),
          Text(s.phone.isEmpty ? '—' : s.phone,
              textDirection: TextDirection.ltr,
              style: const TextStyle(fontSize: 12, color: Colors.white70)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white24, borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.white24),
            ),
            child: Text('🏆 ${NqdiController.fmt(s.bonusTotal)} درهم بونص مقاومة',
                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white)),
          ),
        ]),
      );

  Widget _editCard() => _card(
        title: '✏️ تعديل المعلومات',
        child: Column(children: [
          Row(children: [
            Expanded(child: NqdiField(controller: _first, label: 'الاسم الشخصي', hint: 'الاسم الشخصي')),
            const SizedBox(width: 10),
            Expanded(child: NqdiField(controller: _last, label: 'الاسم العائلي', hint: 'الاسم العائلي')),
          ]),
          const SizedBox(height: 14),
          NqdiField(
            controller: _phone, label: 'رقم الهاتف', hint: '06 XX XX XX XX',
            keyboardType: TextInputType.phone, maxLength: 10, error: _phoneErr,
            onChanged: (_) { if (_phoneErr) setState(() => _phoneErr = false); },
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: PrimaryButton(label: 'حفظ التغييرات ✓', onPressed: _save),
          ),
        ]),
      );

  void _save() {
    final res = ref.read(nqdiProvider.notifier).saveProfile(_first.text, _last.text, _phone.text);
    if (res.status != ActionStatus.success) {
      setState(() => _phoneErr = !NqdiController.isValidPhone(_phone.text));
    } else {
      setState(() => _phoneErr = false);
    }
    showToast(context, res.status == ActionStatus.success
        ? const ActionResult(ActionStatus.success, 'تم حفظ التغييرات ✓')
        : res);
  }

  Widget _resistCard(NqdiState s) => _card(
        title: '💪 إحصائيات المقاومة',
        child: Column(children: [
          _stat('بونص المقاومة المجموع', '${NqdiController.fmt(s.bonusTotal)} درهم', AppColors.green),
          const Divider(height: 1, color: AppColors.border),
          _stat('عدد أيام البيض', '${s.whiteDays} يوم', AppColors.blue),
          const Divider(height: 1, color: AppColors.border),
          _stat('مرات قاومت البلية', '${s.victories} مرة', AppColors.yellowD),
        ]),
      );

  Widget _stat(String name, String val, Color color) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.text2)),
          Text(val, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: color)),
        ]),
      );

  Widget _resetCard() => Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppColors.redXl, border: Border.all(color: AppColors.redL, width: 1.5),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('⚠️ إعادة الضبط الكاملة',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.redD)),
          const SizedBox(height: 6),
          const Text('غتمسح كل المعلومات، المصاريف، والإحصاء. هاد العملية ما تتعكس ش!',
              style: TextStyle(fontSize: 11, color: AppColors.redD, height: 1.6)),
          const SizedBox(height: 14),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [AppColors.red, AppColors.redD]),
              borderRadius: BorderRadius.circular(AppRadius.sm),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(AppRadius.sm),
                onTap: _confirmReset,
                child: const Padding(
                  padding: EdgeInsets.all(14),
                  child: Center(
                    child: Text('إعادة الضبط ومسح كل شي',
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Colors.white)),
                  ),
                ),
              ),
            ),
          ),
        ]),
      );

  void _confirmReset() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('تأكيد', textAlign: TextAlign.right),
        content: const Text('واش بغيتي تمسح كل شي وتبدا من جديد؟', textAlign: TextAlign.right),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لا')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('نعم، امسح', style: TextStyle(color: AppColors.red)),
          ),
        ],
      ),
    );
    if (ok == true && mounted) {
      ref.read(nqdiProvider.notifier).resetAll();
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const OnboardingScreen()),
        (route) => false,
      );
    }
  }

  Widget _card({required String title, required Widget child}) => Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppColors.white, border: Border.all(color: AppColors.border, width: 1.5),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
          const SizedBox(height: 14),
          child,
        ]),
      );
}
