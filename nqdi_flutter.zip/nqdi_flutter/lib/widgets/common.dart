// lib/widgets/common.dart
//
// Small, reusable building blocks shared across screens. Centralising them
// keeps individual screens lean and the visual language consistent.

import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../providers/app_state.dart';

/// Maps an [ActionStatus] to a coloured SnackBar — our equivalent of the
/// web app's toast(). Call from any widget with a BuildContext.
void showToast(BuildContext context, ActionResult result) {
  if (result.message.isEmpty) return;
  final color = switch (result.status) {
    ActionStatus.success => AppColors.green,
    ActionStatus.warning => AppColors.yellowD,
    ActionStatus.error => AppColors.red,
    ActionStatus.danger => AppColors.red,
  };
  ScaffoldMessenger.of(context)
    ..clearSnackBars()
    ..showSnackBar(
      SnackBar(
        content: Text(result.message,
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white)),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(milliseconds: 2200),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
        margin: const EdgeInsets.fromLTRB(40, 0, 40, 90),
      ),
    );
}

/// Primary gradient (green) CTA button.
class PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  const PrimaryButton({super.key, required this.label, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [AppColors.green, AppColors.greenD]),
        borderRadius: BorderRadius.circular(AppRadius.r),
        boxShadow: const [
          BoxShadow(color: Color(0x4D10B981), blurRadius: 16, offset: Offset(0, 4)),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(AppRadius.r),
          onTap: onPressed,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Center(
              child: Text(label,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
            ),
          ),
        ),
      ),
    );
  }
}

/// Neutral / secondary button.
class SecondaryButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  const SecondaryButton({super.key, required this.label, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        backgroundColor: AppColors.off,
        foregroundColor: AppColors.text2,
        side: const BorderSide(color: AppColors.border2, width: 1.5),
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.r)),
      ),
      child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
    );
  }
}

/// The four-segment onboarding progress bar.
class StepBar extends StatelessWidget {
  final int step; // 1..4
  const StepBar({super.key, required this.step});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(4, (i) {
        final index = i + 1;
        final done = index < step;
        final active = index == step;
        return Expanded(
          flex: active ? 2 : 1,
          child: Container(
            height: 4,
            margin: const EdgeInsets.symmetric(horizontal: 2.5),
            decoration: BoxDecoration(
              color: (done || active) ? AppColors.green : AppColors.border,
              borderRadius: BorderRadius.circular(100),
            ),
          ),
        );
      }),
    );
  }
}

/// Uppercase section header with trailing rule.
class SectionHeader extends StatelessWidget {
  final String label;
  const SectionHeader(this.label, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Text(label,
              style: const TextStyle(
                  fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.text)),
          const SizedBox(width: 8),
          const Expanded(child: Divider(color: AppColors.border, height: 1)),
        ],
      ),
    );
  }
}

/// Styled text field used across onboarding & profile.
class NqdiField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final TextInputType? keyboardType;
  final int? maxLength;
  final bool error;
  final ValueChanged<String>? onChanged;

  const NqdiField({
    super.key,
    required this.controller,
    required this.label,
    required this.hint,
    this.keyboardType,
    this.maxLength,
    this.error = false,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Container(width: 5, height: 5,
              decoration: const BoxDecoration(color: AppColors.green, shape: BoxShape.circle)),
          const SizedBox(width: 6),
          Text(label,
              style: const TextStyle(
                  fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.text2)),
        ]),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          maxLength: maxLength,
          onChanged: onChanged,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
          decoration: InputDecoration(
            counterText: '',
            hintText: hint,
            filled: true,
            fillColor: error ? AppColors.redXl : AppColors.off,
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(AppRadius.sm),
              borderSide: BorderSide(color: error ? AppColors.red : AppColors.border, width: 1.5),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(AppRadius.sm),
              borderSide: BorderSide(color: error ? AppColors.red : AppColors.green, width: 1.5),
            ),
          ),
        ),
      ],
    );
  }
}
