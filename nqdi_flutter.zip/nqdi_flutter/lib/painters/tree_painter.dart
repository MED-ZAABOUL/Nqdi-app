// lib/painters/tree_painter.dart
//
// The signature "budget tree". Instead of shipping four SVG assets we draw the
// tree procedurally with CustomPainter so it animates smoothly between health
// stages and stays crisp at any density. Stage is derived from the remaining
// budget percentage, exactly like the web build:
//   >=75 healthy · >=40 stable · >=15 wilting · else dead

import 'package:flutter/material.dart';
import '../core/app_theme.dart';

enum TreeStage { healthy, stable, wilting, dead }

TreeStage stageForPct(double pct) {
  if (pct >= 75) return TreeStage.healthy;
  if (pct >= 40) return TreeStage.stable;
  if (pct >= 15) return TreeStage.wilting;
  return TreeStage.dead;
}

class TreePainter extends CustomPainter {
  /// 0..1 interpolation toward the target stage's foliage fullness.
  final double foliage;
  final TreeStage stage;

  TreePainter({required this.foliage, required this.stage});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final ground = size.height * 0.92;

    _paintGround(canvas, cx, ground, size.width);
    _paintTrunk(canvas, cx, ground, size.height);
    _paintCanopy(canvas, cx, size);
  }

  void _paintGround(Canvas canvas, double cx, double y, double w) {
    final paint = Paint()
      ..color = _groundColor().withValues(alpha: 0.45)
      ..style = PaintingStyle.fill;
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, y), width: w * 0.7, height: 14),
      paint,
    );
  }

  void _paintTrunk(Canvas canvas, double cx, double ground, double h) {
    final trunkColor = switch (stage) {
      TreeStage.healthy => const Color(0xFF795548),
      TreeStage.stable => const Color(0xFF8D6E63),
      TreeStage.wilting => const Color(0xFFA1887F),
      TreeStage.dead => const Color(0xFFBCAAA4),
    };
    final paint = Paint()..color = trunkColor;
    final top = h * 0.42;
    final path = Path()
      ..moveTo(cx - 8, ground)
      ..quadraticBezierTo(cx - 6, (ground + top) / 2, cx - 4, top)
      ..lineTo(cx + 4, top)
      ..quadraticBezierTo(cx + 6, (ground + top) / 2, cx + 8, ground)
      ..close();
    canvas.drawPath(path, paint);

    // Dead tree gets two bare branches reaching out.
    if (stage == TreeStage.dead) {
      final branch = Paint()
        ..color = const Color(0xFF9E9E9E)
        ..strokeWidth = 3.5
        ..strokeCap = StrokeCap.round
        ..style = PaintingStyle.stroke;
      canvas.drawLine(Offset(cx - 4, top + 6), Offset(cx - 34, top - 18), branch);
      canvas.drawLine(Offset(cx + 4, top + 4), Offset(cx + 36, top - 22), branch);
    }
  }

  void _paintCanopy(Canvas canvas, double cx, Size size) {
    if (stage == TreeStage.dead) return; // no leaves on a dead tree

    final colors = _foliageColors();
    final baseR = size.width * (stage == TreeStage.wilting ? 0.14 : 0.27) * (0.6 + 0.4 * foliage);
    final cy = size.height * (stage == TreeStage.wilting ? 0.42 : 0.40);

    // Layered overlapping circles → soft, organic canopy.
    final clusters = <(_Off, double, Color)>[
      (_Off(cx, cy), baseR, colors[0]),
      (_Off(cx - baseR * 0.62, cy + baseR * 0.33), baseR * 0.68, colors[1]),
      (_Off(cx + baseR * 0.62, cy + baseR * 0.33), baseR * 0.68, colors[2]),
      (_Off(cx, cy - baseR * 0.62), baseR * 0.57, colors[3]),
      (_Off(cx - baseR * 0.48, cy - baseR * 0.24), baseR * 0.48, colors[1]),
      (_Off(cx + baseR * 0.48, cy - baseR * 0.24), baseR * 0.48, colors[2]),
    ];

    for (final (off, r, color) in clusters) {
      canvas.drawCircle(Offset(off.x, off.y), r, Paint()..color = color);
    }

    // Fruit dots only on a healthy tree.
    if (stage == TreeStage.healthy) {
      final fruit = [
        (cx - baseR * 0.2, cy - baseR * 0.18, const Color(0xFFF44336), 5.0),
        (cx + baseR * 0.32, cy + baseR * 0.05, const Color(0xFFFF7043), 4.5),
        (cx - baseR * 0.5, cy + baseR * 0.2, const Color(0xFFEF5350), 4.5),
        (cx + baseR * 0.55, cy - baseR * 0.4, const Color(0xFFE53935), 3.5),
      ];
      for (final (fx, fy, c, r) in fruit) {
        canvas.drawCircle(Offset(fx, fy), r * foliage, Paint()..color = c);
      }
      // a little sun
      canvas.drawCircle(Offset(size.width * 0.84, size.height * 0.16), 12,
          Paint()..color = const Color(0xFFFFEE58).withValues(alpha: 0.85));
    }
  }

  List<Color> _foliageColors() {
    switch (stage) {
      case TreeStage.healthy:
        return const [
          Color(0xFF2E7D32), Color(0xFF388E3C), Color(0xFF43A047),
          Color(0xFF66BB6A),
        ];
      case TreeStage.stable:
        return const [
          Color(0xFF558B2F), Color(0xFF689F38), Color(0xFF7CB342),
          Color(0xFF8BC34A),
        ];
      case TreeStage.wilting:
        return const [
          Color(0xFFC0CA33), Color(0xFFD4E157), Color(0xFFCDDC39),
          Color(0xFFAFB42B),
        ];
      case TreeStage.dead:
        return const [Color(0xFFBCAAA4)];
    }
  }

  Color _groundColor() => switch (stage) {
        TreeStage.healthy => const Color(0xFF8BC34A),
        TreeStage.stable => const Color(0xFFA5D6A7),
        TreeStage.wilting => const Color(0xFFD7CCC8),
        TreeStage.dead => const Color(0xFFBCAAA4),
      };

  @override
  bool shouldRepaint(TreePainter old) =>
      old.foliage != foliage || old.stage != stage;
}

class _Off {
  final double x, y;
  const _Off(this.x, this.y);
}

/// Convenience widget that owns the tween between stages.
class BudgetTree extends StatelessWidget {
  final double pct;
  const BudgetTree({super.key, required this.pct});

  @override
  Widget build(BuildContext context) {
    final stage = stageForPct(pct);
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 700),
      curve: Curves.easeOutBack,
      builder: (_, t, __) => CustomPaint(
        painter: TreePainter(foliage: t.clamp(0, 1), stage: stage),
        size: const Size(double.infinity, 165),
      ),
    );
  }
}
