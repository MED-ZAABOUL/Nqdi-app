// lib/providers/app_state.dart
//
// The single source of truth for Nqdi. This is the "ViewModel" layer in our
// MVVM split: it owns all mutable state and every business rule (savings
// engine, tree health, white-day challenge, resistance bonus, validation).
// The UI layer only reads computed getters and calls intent methods — it
// never mutates state directly.

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../models/models.dart';

/// Fraction of net (post-fixed) budget automatically reserved as savings.
const double kSavingsRate = 0.15;
const int kTotalDays = 30;

/// Immutable snapshot of everything the UI needs. Using a value object keeps
/// rebuilds predictable and makes the controller easy to test.
@immutable
class NqdiState {
  final String firstName;
  final String lastName;
  final String phone;
  final double salary;

  /// Selected category ids and per-category monthly estimates.
  final Set<String> activeCategoryIds;
  final Map<String, double> estimates;

  /// Spending state.
  final double totalSpent;
  final double todaySpent;
  final Map<String, double> categorySpent;
  final List<ExpenseLog> logs;
  final String? selectedCategoryId;

  /// Calendar / gamification.
  final int currentDay;
  final double bonusTotal;
  final int whiteDays;
  final int victories;
  final bool whiteDayOn;

  /// Ledgers and per-day breakdown.
  final List<DebtEntry> debtsIOwe; // سالوني
  final List<DebtEntry> debtsOwedToMe; // كنسال
  final Map<int, DayHistory> dayHistory;

  const NqdiState({
    this.firstName = '',
    this.lastName = '',
    this.phone = '',
    this.salary = 0,
    this.activeCategoryIds = const {},
    this.estimates = const {},
    this.totalSpent = 0,
    this.todaySpent = 0,
    this.categorySpent = const {},
    this.logs = const [],
    this.selectedCategoryId,
    this.currentDay = 1,
    this.bonusTotal = 0,
    this.whiteDays = 0,
    this.victories = 0,
    this.whiteDayOn = false,
    this.debtsIOwe = const [],
    this.debtsOwedToMe = const [],
    this.dayHistory = const {},
  });

  NqdiState copyWith({
    String? firstName,
    String? lastName,
    String? phone,
    double? salary,
    Set<String>? activeCategoryIds,
    Map<String, double>? estimates,
    double? totalSpent,
    double? todaySpent,
    Map<String, double>? categorySpent,
    List<ExpenseLog>? logs,
    Object? selectedCategoryId = _sentinel,
    int? currentDay,
    double? bonusTotal,
    int? whiteDays,
    int? victories,
    bool? whiteDayOn,
    List<DebtEntry>? debtsIOwe,
    List<DebtEntry>? debtsOwedToMe,
    Map<int, DayHistory>? dayHistory,
  }) {
    return NqdiState(
      firstName: firstName ?? this.firstName,
      lastName: lastName ?? this.lastName,
      phone: phone ?? this.phone,
      salary: salary ?? this.salary,
      activeCategoryIds: activeCategoryIds ?? this.activeCategoryIds,
      estimates: estimates ?? this.estimates,
      totalSpent: totalSpent ?? this.totalSpent,
      todaySpent: todaySpent ?? this.todaySpent,
      categorySpent: categorySpent ?? this.categorySpent,
      logs: logs ?? this.logs,
      selectedCategoryId: selectedCategoryId == _sentinel
          ? this.selectedCategoryId
          : selectedCategoryId as String?,
      currentDay: currentDay ?? this.currentDay,
      bonusTotal: bonusTotal ?? this.bonusTotal,
      whiteDays: whiteDays ?? this.whiteDays,
      victories: victories ?? this.victories,
      whiteDayOn: whiteDayOn ?? this.whiteDayOn,
      debtsIOwe: debtsIOwe ?? this.debtsIOwe,
      debtsOwedToMe: debtsOwedToMe ?? this.debtsOwedToMe,
      dayHistory: dayHistory ?? this.dayHistory,
    );
  }

  static const _sentinel = Object();

  // ─────────────────────── DERIVED / COMPUTED VALUES ───────────────────────
  // These mirror the helper functions from the web build but live here so the
  // UI stays declarative.

  List<ExpenseCategory> get activeCategories =>
      kCategories.where((c) => activeCategoryIds.contains(c.id)).toList();

  /// Sum of estimates for fixed-bucket categories.
  double get fixedTotal => activeCategories
      .where((c) => c.bucket == CategoryBucket.fixed)
      .fold(0.0, (s, c) => s + (estimates[c.id] ?? 0));

  /// Net spendable income after fixed obligations (never below 0).
  double get fluidBudget => (salary - fixedTotal).clamp(0, double.infinity);

  /// 15% automated savings target on the net budget.
  double get savingsGoal => fluidBudget * kSavingsRate;

  /// What remains to actually spend after reserving savings.
  double get spendableAfterSavings => fluidBudget - savingsGoal;

  double get remaining => salary - totalSpent;

  /// Percentage of budget still healthy (drives the tree).
  double get healthPct =>
      salary <= 0 ? 0 : (remaining / salary * 100).clamp(0, double.infinity);

  int get daysLeft => (kTotalDays - currentDay + 1).clamp(1, kTotalDays);

  /// Daily allowance = remaining budget spread over remaining days.
  double get dailyAllowance => remaining / daysLeft;

  double get dangerSpent => activeCategories
      .where((c) => c.isDanger)
      .fold(0.0, (s, c) => s + (categorySpent[c.id] ?? 0));

  double get fixedSpent => activeCategories
      .where((c) => c.bucket == CategoryBucket.fixed)
      .fold(0.0, (s, c) => s + (categorySpent[c.id] ?? 0));

  double get variableSpent => activeCategories
      .where((c) => c.bucket == CategoryBucket.variable)
      .fold(0.0, (s, c) => s + (categorySpent[c.id] ?? 0));

  /// Surplus (or deficit) for today vs the daily allowance.
  double get todayDiff => dailyAllowance - todaySpent;

  String get fullName => '$firstName $lastName'.trim();

  bool get hasDebts => debtsIOwe.isNotEmpty || debtsOwedToMe.isNotEmpty;
}

/// Result of a user intent — lets the UI show the right toast without the
/// controller knowing anything about widgets.
enum ActionStatus { success, warning, error, danger }

class ActionResult {
  final ActionStatus status;
  final String message;
  const ActionResult(this.status, this.message);
}

/// The StateNotifier that drives the whole app.
class NqdiController extends StateNotifier<NqdiState> {
  NqdiController() : super(_freshState());

  static NqdiState _freshState() => NqdiState(
        // By default every category is selected (matches the web `checked` Set).
        activeCategoryIds: kCategories.map((c) => c.id).toSet(),
      );

  // ───────────────────────────── VALIDATION ─────────────────────────────

  /// Names must be letters only — no digits (ASCII or Arabic-Indic) or symbols.
  /// Mirrors the regex used in the web build.
  static bool isValidName(String v) {
    final value = v.trim();
    if (value.isEmpty) return false;
    final letters = RegExp(r"^[A-Za-z\u0600-\u06FF\u0750-\u077F\s'’\-]+$");
    final hasDigit = RegExp(r"[0-9\u0660-\u0669]");
    return letters.hasMatch(value) && !hasDigit.hasMatch(value);
  }

  /// Moroccan mobile: starts with 06 or 07, exactly 10 digits.
  static bool isValidPhone(String v) =>
      RegExp(r'^(06|07)\d{8}$').hasMatch(v.trim());

  // ──────────────────────────── ONBOARDING ────────────────────────────

  ActionResult submitProfile(String first, String last, String phone) {
    if (!isValidName(first)) {
      return const ActionResult(ActionStatus.error, 'الاسم الشخصي خاصو يكون غير حروف!');
    }
    if (!isValidName(last)) {
      return const ActionResult(ActionStatus.error, 'الاسم العائلي خاصو يكون غير حروف!');
    }
    if (!isValidPhone(phone)) {
      return const ActionResult(ActionStatus.error, 'رقم الهاتف غير صحيح!');
    }
    state = state.copyWith(
      firstName: first.trim(),
      lastName: last.trim(),
      phone: phone.trim(),
    );
    return const ActionResult(ActionStatus.success, 'تم الحفظ');
  }

  ActionResult setSalary(double value) {
    if (value <= 0) {
      return const ActionResult(ActionStatus.warning, 'دخل الميزانية ديالك أولاً!');
    }
    state = state.copyWith(salary: value);
    return const ActionResult(ActionStatus.success, 'تمت');
  }

  void toggleCategory(String id) {
    final next = Set<String>.from(state.activeCategoryIds);
    next.contains(id) ? next.remove(id) : next.add(id);
    state = state.copyWith(activeCategoryIds: next);
  }

  ActionResult confirmCategories() {
    if (state.activeCategoryIds.isEmpty) {
      return const ActionResult(ActionStatus.warning, 'عزل فئة واحدة على الأقل!');
    }
    return const ActionResult(ActionStatus.success, 'تمت');
  }

  void setEstimate(String categoryId, double value) {
    final next = Map<String, double>.from(state.estimates)..[categoryId] = value;
    state = state.copyWith(estimates: next);
  }

  /// Called when onboarding completes — initialises a clean spending ledger.
  void finalizeOnboarding() {
    final spent = {for (final c in state.activeCategories) c.id: 0.0};
    state = state.copyWith(categorySpent: spent);
  }

  // ──────────────────────────── EXPENSES ────────────────────────────

  void selectLogCategory(String? id) =>
      state = state.copyWith(selectedCategoryId: id);

  /// Core expense recorder. Returns a result the UI turns into a toast.
  ActionResult logExpense(double amount, {String? categoryId}) {
    final catId = categoryId ?? state.selectedCategoryId;
    if (amount <= 0) {
      return const ActionResult(ActionStatus.warning, 'دخل مبلغاً صحيحاً!');
    }
    if (catId == null) {
      return const ActionResult(ActionStatus.warning, 'عزل فئة المصروف أولاً!');
    }
    if (state.whiteDayOn) {
      return const ActionResult(
          ActionStatus.error, 'راك في تحدي النهار البيض! ما تخسر ش 💪');
    }
    final cat = state.activeCategories.firstWhere(
      (c) => c.id == catId,
      orElse: () => kCategories.firstWhere((c) => c.id == catId),
    );

    final spent = Map<String, double>.from(state.categorySpent)
      ..update(cat.id, (v) => v + amount, ifAbsent: () => amount);

    final log = ExpenseLog(
      id: DateTime.now().millisecondsSinceEpoch,
      categoryId: cat.id,
      categoryName: cat.name,
      categoryIcon: cat.icon,
      amount: amount,
      danger: cat.isDanger,
      time: DateFormat.Hm().format(DateTime.now()),
      day: state.currentDay,
    );

    // Update per-day history immutably.
    final history = Map<int, DayHistory>.from(state.dayHistory);
    final dh = history[state.currentDay] ?? DayHistory();
    final updatedDh = DayHistory(logs: [...dh.logs, log], total: dh.total + amount);
    history[state.currentDay] = updatedDh;

    state = state.copyWith(
      totalSpent: state.totalSpent + amount,
      todaySpent: state.todaySpent + amount,
      categorySpent: spent,
      logs: [log, ...state.logs],
      dayHistory: history,
      selectedCategoryId: null,
    );

    return cat.isDanger
        ? const ActionResult(ActionStatus.danger, '⚠️ البلية كتاكل فلوسك!')
        : ActionResult(ActionStatus.success, 'تم تقييد ${fmt(amount)} درهم ✓');
  }

  // ─────────────────────── GAMIFICATION ───────────────────────

  /// Toggle the "نهار بيض" (no-spend day) challenge. Completing it (turning it
  /// off after a zero-spend day) increments the streak.
  ActionResult toggleWhiteDay(bool on) {
    if (!on && state.whiteDayOn && state.todaySpent == 0) {
      state = state.copyWith(whiteDayOn: false, whiteDays: state.whiteDays + 1);
      return const ActionResult(ActionStatus.success, 'نهار بيض مكمّل! 🤍');
    }
    state = state.copyWith(whiteDayOn: on);
    return on
        ? const ActionResult(ActionStatus.success, 'تحدي النهار البيض فاعل! 🌟')
        : const ActionResult(ActionStatus.warning, '');
  }

  /// "لیوم قاومت" — resisting a vice grants a bonus equal to the average of
  /// your danger-category estimates (default 20 dh if none set).
  ActionResult claimVictory() {
    final danger = state.activeCategories.where((c) => c.isDanger).toList();
    if (danger.isEmpty) {
      return const ActionResult(ActionStatus.warning, 'ما عندك فئة بلية!');
    }
    final sum = danger.fold(0.0, (s, c) => s + (state.estimates[c.id] ?? 0));
    final bonus = sum > 0 ? sum / danger.length : 20.0;
    state = state.copyWith(
      bonusTotal: state.bonusTotal + bonus,
      victories: state.victories + 1,
    );
    return ActionResult(ActionStatus.success, '+${fmt(bonus)} درهم تزادت للبونص');
  }

  // ─────────────────────────── DEBTS ───────────────────────────

  ActionResult addDebt({required bool iOwe, required String name, required double amount}) {
    if (name.trim().isEmpty) {
      return const ActionResult(ActionStatus.warning, 'دخل الاسم!');
    }
    if (amount <= 0) {
      return const ActionResult(ActionStatus.warning, 'دخل المبلغ!');
    }
    final entry = DebtEntry(
        id: DateTime.now().millisecondsSinceEpoch, name: name.trim(), amount: amount);
    if (iOwe) {
      state = state.copyWith(debtsIOwe: [...state.debtsIOwe, entry]);
    } else {
      state = state.copyWith(debtsOwedToMe: [...state.debtsOwedToMe, entry]);
    }
    return const ActionResult(ActionStatus.success, 'تمت الإضافة');
  }

  void removeDebt({required bool iOwe, required int id}) {
    if (iOwe) {
      state = state.copyWith(
          debtsIOwe: state.debtsIOwe.where((d) => d.id != id).toList());
    } else {
      state = state.copyWith(
          debtsOwedToMe: state.debtsOwedToMe.where((d) => d.id != id).toList());
    }
  }

  // ─────────────────────────── PROFILE ───────────────────────────

  ActionResult saveProfile(String first, String last, String phone) =>
      submitProfile(first, last, phone);

  /// Wipe everything back to a fresh onboarding state.
  void resetAll() => state = _freshState();

  // ─────────────────────────── HELPERS ───────────────────────────

  /// Round and localise an amount (Arabic-Morocco grouping).
  static String fmt(double n) =>
      NumberFormat.decimalPattern('ar_MA').format(n.round());
}

/// Global provider. `ref.watch(nqdiProvider)` gives the current snapshot;
/// `ref.read(nqdiProvider.notifier)` exposes the intent methods.
final nqdiProvider =
    StateNotifierProvider<NqdiController, NqdiState>((ref) => NqdiController());
