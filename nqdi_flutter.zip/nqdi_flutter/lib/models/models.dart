// lib/models/models.dart
//
// Immutable-ish domain models for Nqdi. Kept deliberately small and free of
// any Flutter import so they can be unit-tested in isolation.

/// Which budgeting bucket a category belongs to.
enum CategoryBucket { fixed, variable, danger }

/// A spending category (e.g. الكرا / rent, البلية / vice).
class ExpenseCategory {
  final String id;
  final String name; // Darija display name
  final String icon; // emoji
  final CategoryBucket bucket;

  const ExpenseCategory({
    required this.id,
    required this.name,
    required this.icon,
    required this.bucket,
  });

  bool get isDanger => bucket == CategoryBucket.danger;
}

/// A single logged expense.
class ExpenseLog {
  final int id;
  final String categoryId;
  final String categoryName;
  final String categoryIcon;
  final double amount;
  final bool danger;
  final String time; // formatted HH:mm
  final int day; // 1..30

  const ExpenseLog({
    required this.id,
    required this.categoryId,
    required this.categoryName,
    required this.categoryIcon,
    required this.amount,
    required this.danger,
    required this.time,
    required this.day,
  });
}

/// A debt entry — money owed to me, or money I owe.
class DebtEntry {
  final int id;
  final String name;
  final double amount;

  const DebtEntry({required this.id, required this.name, required this.amount});
}

/// Aggregated history for a single day.
class DayHistory {
  final List<ExpenseLog> logs;
  double total;

  DayHistory({List<ExpenseLog>? logs, this.total = 0})
      : logs = logs ?? <ExpenseLog>[];
}

/// Master list of categories. Mirrors the CATEGORIES array from the web app.
const List<ExpenseCategory> kCategories = [
  ExpenseCategory(id: 'rent', name: 'الكرا', icon: '🏠', bucket: CategoryBucket.fixed),
  ExpenseCategory(id: 'utils', name: 'الما والضو', icon: '💡', bucket: CategoryBucket.fixed),
  ExpenseCategory(id: 'wifi', name: 'الويفي', icon: '📶', bucket: CategoryBucket.fixed),
  ExpenseCategory(id: 'parents', name: 'الوالدين', icon: '🤲', bucket: CategoryBucket.fixed),
  ExpenseCategory(id: 'credit', name: 'الكريديت', icon: '💳', bucket: CategoryBucket.fixed),
  ExpenseCategory(id: 'quraa', name: 'القرعة', icon: '🏦', bucket: CategoryBucket.fixed),
  ExpenseCategory(id: 'market', name: 'السويقة', icon: '🛒', bucket: CategoryBucket.variable),
  ExpenseCategory(id: 'gym', name: 'لاصال', icon: '🏋️', bucket: CategoryBucket.variable),
  ExpenseCategory(id: 'cafe', name: 'القهوة والريزو', icon: '☕', bucket: CategoryBucket.variable),
  ExpenseCategory(id: 'eatout', name: 'الماكلة برا', icon: '🍔', bucket: CategoryBucket.variable),
  ExpenseCategory(id: 'grooming', name: 'التحسينة', icon: '💈', bucket: CategoryBucket.variable),
  ExpenseCategory(id: 'clothes', name: 'الكسوة', icon: '👗', bucket: CategoryBucket.variable),
  ExpenseCategory(id: 'health', name: 'الدوا', icon: '💊', bucket: CategoryBucket.variable),
  ExpenseCategory(id: 'fun', name: 'النشاط', icon: '🎉', bucket: CategoryBucket.variable),
  ExpenseCategory(id: 'blia', name: 'البلية', icon: '🚬', bucket: CategoryBucket.danger),
  ExpenseCategory(id: 'khamra', name: 'المخفية', icon: '🎭', bucket: CategoryBucket.danger),
];

/// Prosperity tips ticker content.
const List<String> kTips = [
  'هنا غتلقا نصائح ذكية كفاش تبني حياتك، وتحكم في مصروفك بلا ما تزير راسك بزاف 🌱',
  'جمع درهم على درهم يولي جبل، فكر في شجرتك قبل ما تخسر فلوسك في الخوا 🌲',
  'اللي كيصبر على صغار المصاريف هو اللي كيجمع كبارها في آخر الشهر 💰',
  'راجع حسابك كل يوم باش ما يفاجئك ش العجز في آخر الشهر 📊',
  'الميزانية مشي عقاب، هي حريتك باش تعيش بلا قلق على الفلوس ✨',
  'خسر على الصحة والعيلة أحسن من الأكل برا كل يوم – الاقتصاد فالصغيرة 🏠',
];
